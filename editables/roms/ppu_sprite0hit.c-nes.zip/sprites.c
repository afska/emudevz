#include <string.h>
#include "neslib.h"

//#link "chr_generic.s"

#define PPUSTATUS (*(volatile unsigned char*)0x2002)
#define PPUADDR   (*(volatile unsigned char*)0x2006)
#define PPUDATA   (*(volatile unsigned char*)0x2007)

#define STATUS_VBLANK 0x80
#define STATUS_SPR0HIT 0x40
#define MID_Y_TILE 12

const char PALETTE[32] = {
  0x03,
  0x11,0x30,0x27,0x00,  0x1c,0x20,0x2c,0x00,
  0x00,0x10,0x20,0x00,  0x06,0x16,0x26,0x00,
  0x16,0x35,0x24,0x00,  0x00,0x37,0x25,0x00,
  0x0d,0x2d,0x3a,0x00,  0x0d,0x27,0x2a
};

static const char TITLE_WAIT[] = "Sprite-zero hit test";

static void write_backdrop(unsigned char color) {
  ppu_off();
  PPUADDR = 0x3F;
  PPUADDR = 0x00;
  PPUDATA = color;
  ppu_on_all();
}

static void draw_initial_screen(void) {
  unsigned char i;
  ppu_off();
  pal_all(PALETTE);
  vram_adr(NTADR_A(2,2));
  vram_write(TITLE_WAIT, sizeof(TITLE_WAIT) - 1);
  vram_adr(NTADR_A(0, MID_Y_TILE));
  for (i = 0; i < 32; i++) vram_put('-');
  ppu_on_all();
}

void main(void){
  unsigned char oam_id;
  unsigned char x;
  unsigned char y;
  unsigned char topColor;
  unsigned char bottomColor;
  unsigned char got_hit;
  unsigned char s;

  x = 120;
  y = 200;
  topColor = 0x03;
  bottomColor = 0x11;

  oam_clear();
  draw_initial_screen();
  
  write_backdrop(topColor);

  for (;;) {
    if (!got_hit && y > 8) y -= 2;
        
    oam_id = 0;
    oam_id = oam_spr(x, y, 65, 0, oam_id);
    oam_hide_rest(oam_id);
        
    ppu_wait_frame();
   
    do { s = PPUSTATUS; } while(s & STATUS_VBLANK);
    do { s = PPUSTATUS; } while(s & STATUS_SPR0HIT);

    got_hit = 0;
    for (;;) {
      s = PPUSTATUS;
      if (s & STATUS_SPR0HIT) { got_hit = 1; break; }
      if (s & STATUS_VBLANK) { break; }
    }

    if (got_hit) {
      write_backdrop(bottomColor);
      
      while (true) {}
    }
  }
}
