#include <stdlib.h>
#include <string.h>

#include "neslib.h"

#include <nes.h>

//#link "chr_generic.s"

#define TILE 0xd8
#define ATTR 0

const unsigned char metasprite[] = {
  0,  0,  TILE+0, ATTR,
  0,  8,  TILE+1, ATTR,
  8,  0,  TILE+2, ATTR,
  8,  8,  TILE+3, ATTR,
  128
};

const char PALETTE[32] = {
  0x03,
  0x11,0x30,0x27,0x0,
  0x1c,0x20,0x2c,0x0,
  0x00,0x10,0x20,0x0,
  0x06,0x16,0x26,0x0,

  0x16,0x35,0x24,0x0,
  0x00,0x37,0x25,0x0,
  0x0d,0x2d,0x3a,0x0,
  0x0d,0x27,0x2a
};

#define NUM_ACTORS 16

byte actor_x[NUM_ACTORS];
byte actor_y[NUM_ACTORS];
sbyte actor_dx[NUM_ACTORS];
sbyte actor_dy[NUM_ACTORS];

void setup_graphics(void) {
  byte y;
  byte x;

  oam_clear();
  pal_all(PALETTE);

  ppu_off();

  for (y = 2; y < 28; ++y) {
    vram_adr(NTADR_A(0, y));
    vram_put(1);
  }

  vram_adr(NTADR_A(4, 6));
  vram_fill(2, 12);

  vram_adr(NTADR_A(10, 12));
  vram_fill(3, 16);

  for (x = 20; x < 28; ++x) {
    vram_adr(NTADR_A(x, 18));
    vram_put(2);
    vram_adr(NTADR_A(x, 22));
    vram_put(2);
  }
  for (y = 19; y < 22; ++y) {
    vram_adr(NTADR_A(20, y));
    vram_put(2);
    vram_adr(NTADR_A(27, y));
    vram_put(2);
  }

  ppu_on_all();
}

void main(void) {
  char i;
  char oam_id;
  unsigned char combo_index;
  unsigned char frame_in_combo;
  unsigned char frames_per_combo;
  unsigned char mask;
  unsigned char b1;
  unsigned char b2;
  unsigned char b3;
  unsigned char b4;

  setup_graphics();

  for (i = 0; i < NUM_ACTORS; i++) {
    actor_x[i] = (byte)rand();
    actor_y[i] = (byte)rand();
    actor_dx[i] = ((byte)rand() & 7) - 3;
    actor_dy[i] = ((byte)rand() & 7) - 3;
  }

  combo_index = 0;
  frame_in_combo = 0;
  frames_per_combo = 4;

  while (1) {
    b1 = (combo_index & 0x01) ? 1 : 0;
    b2 = (combo_index & 0x02) ? 1 : 0;
    b3 = (combo_index & 0x04) ? 1 : 0;
    b4 = (combo_index & 0x08) ? 1 : 0;

    mask = 0;
    if (b1) mask |= (1 << 1);
    if (b2) mask |= (1 << 2);
    if (b3) mask |= (1 << 3);
    if (b4) mask |= (1 << 4);

    ppu_mask(mask);

    oam_id = 0;
    for (i = 0; i < NUM_ACTORS; i++) {
      oam_id = oam_meta_spr(actor_x[i], actor_y[i], oam_id, metasprite);
      actor_x[i] += actor_dx[i];
      actor_y[i] += actor_dy[i];
    }
    if (oam_id != 0) oam_hide_rest(oam_id);

    ppu_wait_frame();

    ++frame_in_combo;
    if (frame_in_combo >= frames_per_combo) {
      frame_in_combo = 0;
      combo_index = (combo_index + 1) & 15;
    }
  }
}
