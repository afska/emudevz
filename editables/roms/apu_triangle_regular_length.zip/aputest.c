#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "neslib.h"

#include "apu.h"
//#link "apu.c"

#include "vrambuf.h"
//#link "vrambuf.c"

//#link "chr_generic.s"

#define APUSTATUS      (*(volatile unsigned char*)0x4015)
#define APU_TRI_LINEAR (*(volatile unsigned char*)0x4008)

typedef struct {
  word period;      // 11-bit timer
  byte lengthIndex; // 0..31
} TriTest;

#define NUM_TESTS 6
static const TriTest TESTS[NUM_TESTS] = {
  {260,  5},
  {300,  7},
  {220, 11},
  {240, 13},
  {200, 15},
  {160, 29},
};

static void apply_test(const TriTest* t) {
  APU_ENABLE(0x04);                        // triangle on
  APU_TRI_LINEAR = 0x7F;                   // control=0, linear reload high
  APU_TRIANGLE_LENGTH(t->period, t->lengthIndex);
}

static void keep_linear_alive(void) {
  APU_TRI_LINEAR = 0x7F;                   // refresh linear so only LENGTH gates sound
}

static void print_test(byte idx, const TriTest* t) {
  char line[32];
  sprintf(line, "TRI len=%u per=%u  #%u",
          (unsigned)t->lengthIndex, (unsigned)t->period, (unsigned)idx);
  vrambuf_clear();
  vrambuf_put(NTADR_A(1,1), line, (byte)strlen(line));
}

void main(void) {
  byte i;
  byte s;
  unsigned totalFrames = 0;

  pal_col(1,0x04);
  pal_col(2,0x20);
  pal_col(3,0x30);

  apu_init();
  set_vram_update(updbuf);
  ppu_on_all();

  for (i = 0; i < NUM_TESTS; i++) {
    unsigned guard = 0;
    apply_test(&TESTS[i]);
    print_test(i, &TESTS[i]);

    while ((APUSTATUS & 0x04) && guard < 40 && totalFrames < 290) {
      ppu_wait_nmi();
      keep_linear_alive();
      guard++;
      totalFrames++;
    }

    APU_ENABLE(0x00);
    for (s = 0; s < 6 && totalFrames < 298; s++) {
      ppu_wait_nmi();
      totalFrames++;
    }
  }

  APU_ENABLE(0x00);
  for (;;) ppu_wait_nmi();
}
