#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "neslib.h"

#include "apu.h"
//#link "apu.c"

#include "vrambuf.h"
//#link "vrambuf.c"

//#link "chr_generic.s"

typedef struct {
  byte channel;       // 0 = Pulse 1, 1 = Pulse 2
  word period;        // 11-bit timer
  byte duty;          // 0x00, 0x40, 0x80, 0xC0
  byte decay;         // 0..15
  byte lengthIndex;   // 0..15
  byte sweepPeriod;   // 0..7 (use >0 for audible sweeps)
  byte sweepShift;    // 0..7
  byte up;            // 1 = sweep up, 0 = sweep down (negate)
} SweepTest;

#define FRAMES_PER_TEST 28   // 28 * 8 = 224 total frames
#define NUM_TESTS 8

static const SweepTest TESTS[NUM_TESTS] = {
  // channel, period, duty, decay, len, spd, sh, up
  {0, 253, 0x80, 15, 12, 2, 2, 1}, // P1 up
  {0, 400, 0x80, 15,  6, 3, 3, 0}, // P1 down
  {1, 253, 0x40, 15, 12, 2, 2, 1}, // P2 up
  {1, 400, 0x40, 15,  6, 3, 3, 0}, // P2 down
  {0, 200, 0xC0, 15, 10, 5, 2, 1}, // P1 up (faster)
  {0, 500, 0xC0, 15,  4, 4, 3, 0}, // P1 down (slower)
  {1, 200, 0x00, 15, 10, 5, 2, 1}, // P2 up (faster)
  {1, 500, 0x00, 15,  4, 4, 3, 0}, // P2 down (slower)
};

static void apply_test(const SweepTest* t) {
  byte enableMask = (t->channel == 0) ? 0x01 : 0x02; // Pulse1 or Pulse2
  APU_ENABLE(enableMask);
  APU_PULSE_DECAY(t->channel, t->period, t->duty, t->decay, t->lengthIndex);
  APU_PULSE_SWEEP(t->channel, t->sweepPeriod, t->sweepShift, t->up);
}

static void print_test(byte idx, const SweepTest* t) {
  char line[32];
  sprintf(line, "#%u P%u %s L%u T=%u SP=%u SH=%u",
          (unsigned)idx,
          (unsigned)(t->channel + 1),
          t->up ? "UP " : "DOWN",
          (unsigned)t->lengthIndex,
          (unsigned)t->period,
          (unsigned)t->sweepPeriod,
          (unsigned)t->sweepShift);
  vrambuf_clear();
  vrambuf_put(NTADR_A(1,1), line, (byte)strlen(line));
}

void main(void) {
  byte testIndex = 0;
  byte frameInTest = 0;

  pal_col(1,0x04);
  pal_col(2,0x20);
  pal_col(3,0x30);

  apu_init();
  set_vram_update(updbuf);
  ppu_on_all();

  apply_test(&TESTS[0]);
  print_test(0, &TESTS[0]);

  for (;;) {
    ppu_wait_nmi();

    frameInTest++;
    if (frameInTest >= FRAMES_PER_TEST) {
      frameInTest = 0;
      testIndex++;
      if (testIndex >= NUM_TESTS) break;
      apply_test(&TESTS[testIndex]);
      print_test(testIndex, &TESTS[testIndex]);
    }
  }

  APU_ENABLE(0x00); // silence
  for (;;) {
    ppu_wait_nmi();
  }
}
