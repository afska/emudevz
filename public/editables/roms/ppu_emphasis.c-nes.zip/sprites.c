
/*
Sprite demo.
Animate all 64 hardware sprites.
*/

#include <stdlib.h>
#include <string.h>

// include NESLIB header
#include "neslib.h"

// link the pattern table into CHR ROM
//#link "chr_generic.s"

/*{pal:"nes",layout:"nes"}*/
const char PALETTE[32] = { 
  0x03,			// screen color

  0x11,0x30,0x27,0x0,	// background palette 0
  0x1c,0x20,0x2c,0x0,	// background palette 1
  0x00,0x10,0x20,0x0,	// background palette 2
  0x06,0x16,0x26,0x0,   // background palette 3

  0x16,0x35,0x24,0x0,	// sprite palette 0
  0x00,0x37,0x25,0x0,	// sprite palette 1
  0x0d,0x2d,0x3a,0x0,	// sprite palette 2
  0x0d,0x27,0x2a	// sprite palette 3
};

// setup PPU and tables
void setup_graphics() {
  // clear sprites
  oam_clear();
  // set palette colors
  pal_all(PALETTE);
  // turn on PPU
  ppu_on_all();
}

// number of actors
#define NUM_ACTORS 32		// 64 sprites (maximum)

// actor x/y positions
byte actor_x[NUM_ACTORS];	// horizontal coordinates
byte actor_y[NUM_ACTORS];	// vertical coordinates

// actor x/y deltas per frame (signed)
sbyte actor_dx[NUM_ACTORS];	// horizontal velocity
sbyte actor_dy[NUM_ACTORS];	// vertical velocity

// main program
void main() {
  char i;	// actor index
  char oam_id;	// sprite ID
  byte r, g, b, gr;
  char message[16];
  
  // initialize actors with random values
  for (i=0; i<NUM_ACTORS; i++) {
    actor_x[i] = rand();
    actor_y[i] = rand();
    actor_dx[i] = (rand() & 7) - 3;
    actor_dy[i] = (rand() & 7) - 3;
  }
  // initialize PPU
  setup_graphics();
  
  // infinite loop
  while (1) {
    byte mask = MASK_SPR | MASK_BG;

    for (r = 0; r < 2; r++) {
      for (g = 0; g < 2; g++) {
        for (b = 0; b < 2; b++) {
          for (gr = 0; gr < 2; gr++) {
            // Update the mask
            if (r == 1) mask |= MASK_TINT_RED;
            else mask &= ~MASK_TINT_RED;

            if (g == 1) mask |= MASK_TINT_GREEN;
            else mask &= ~MASK_TINT_GREEN;

            if (b == 1) mask |= MASK_TINT_BLUE;
            else mask &= ~MASK_TINT_BLUE;

            if (gr == 1) mask |= MASK_MONO;
            else mask &= ~MASK_MONO;

            // Manually create the message
            message[0] = 'R'; message[1] = ':';
            message[2] = '0' + r; message[3] = ' ';
            message[4] = 'G'; message[5] = ':';
            message[6] = '0' + g; message[7] = ' ';
            message[8] = 'B'; message[9] = ':';
            message[10] = '0' + b; message[11] = ' ';
            message[12] = 'M'; message[13] = ':';
            message[14] = '0' + gr; message[15] = '\0';

            // Write the message to the screen
            vram_adr(NTADR_A(1, 2)); // Adjust position as needed
            vram_write(message, 15); // Write the new message
            
            // start with OAMid/sprite 0
            oam_id = 0;
            // draw and move all actors
            for (i=0; i<NUM_ACTORS; i++) {
              oam_id = oam_spr(actor_x[i], actor_y[i], i, i, oam_id);
              actor_x[i] += actor_dx[i];
              actor_y[i] += actor_dy[i];
              }

            // Apply the mask
            ppu_mask(mask);
            
            // Wait 15 frames
            for (i = 0; i < 15; i++)
              ppu_wait_frame();
          }
        }
      }
    }

    ppu_wait_frame();
  }
}
