#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "neslib.h"

#include "apu.h"
//#link "apu.c"

#include "vrambuf.h"
//#link "vrambuf.c"

//#link "chr_generic.s"

#define APU_NOISE_ENV  (*(volatile unsigned char*)0x400C) // [5]=loop, [4]=const, [3..0]=vol/decay
#define APU_NOISE_PER  (*(volatile unsigned char*)0x400E) // [7]=mode(short), [3..0]=period index
#define APU_NOISE_LEN  (*(volatile unsigned char*)0x400F) // write reloads length+envelope

typedef struct {
  byte loop;
  byte constant;
  byte val;          // 0..15
  byte periodIndex;  // 0..15
  byte buzz;         // 0/1
  byte lengthIndex;  // 0..31
  byte frames;       // NMI frames to play
} NoiseEnvTest;

#define NUM_TESTS 10
static const NoiseEnvTest TESTS[NUM_TESTS] = {
  {0,0, 4,  3,0, 20, 28},
  {0,0, 8,  3,0, 20, 36},
  {0,0,12,  3,0, 20, 44},
  {1,0, 4,  3,0, 20, 32},
  {1,0,12,  3,0, 20, 48},
  {0,1, 4,  3,0, 20, 28},
  {0,1,12,  3,0, 20, 28},
  {0,0, 6,  2,1, 20, 36},
  {1,0, 6,  2,1, 20, 36},
  {0,1,10,  2,1, 20, 28},
};

static void noise_start(const NoiseEnvTest* t) {
  APU_ENABLE(0x08);
  APU_NOISE_ENV = (t->loop ? 0x20 : 0x00) | (t->constant ? 0x10 : 0x00) | (t->val & 0x0F);
  APU_NOISE_PER = (t->buzz ? 0x80 : 0x00) | (t->periodIndex & 0x0F);
  APU_NOISE_LEN = (t->lengthIndex & 0x1F) << 3;
}

static void print_test(byte pass, byte idx, const NoiseEnvTest* t) {
  char line[32];
  sprintf(line, "P%u #%u %s %s v=%u per=%u bz=%u",
          (unsigned)(pass + 1), (unsigned)idx,
          t->constant ? "CONST" : "DEC",
          t->loop ? "LOOP" : "ONCE",
          (unsigned)t->val, (unsigned)t->periodIndex, (unsigned)t->buzz);
  vrambuf_clear();
  vrambuf_put(NTADR_A(1,1), line, (byte)strlen(line));
}

void main(void) {
  byte pass, i, f;

  pal_col(1,0x04);
  pal_col(2,0x20);
  pal_col(3,0x30);

  apu_init();
  set_vram_update(updbuf);
  ppu_on_all();

  for (pass = 0; pass < 3; pass++) {
    for (i = 0; i < NUM_TESTS; i++) {
      noise_start(&TESTS[i]);
      print_test(pass, i, &TESTS[i]);

      for (f = 0; f < TESTS[i].frames; f++) ppu_wait_nmi();

      APU_ENABLE(0x00);
      for (f = 0; f < 6; f++) ppu_wait_nmi();
    }
  }

  APU_ENABLE(0x00);
  for (;;) ppu_wait_nmi();
}
