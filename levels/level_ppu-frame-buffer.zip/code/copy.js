filesystem.write(
	`${Drive.DOCS_DIR}/ppu/frame_buffer.png`,
	level.media["frameBuffer.png"]
);
